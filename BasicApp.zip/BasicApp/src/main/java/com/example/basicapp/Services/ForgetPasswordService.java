package com.example.basicapp.Services;

public interface ForgetPasswordService {
    void initiatePasswordReset(String email);

}
