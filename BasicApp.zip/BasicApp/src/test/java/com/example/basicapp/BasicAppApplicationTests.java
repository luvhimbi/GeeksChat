package com.example.basicapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
